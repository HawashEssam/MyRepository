package com.example.hawash.mycalculator;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.speech.tts.TextToSpeech;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {
    boolean isclicked=false,sound=false;
    TextToSpeech tospeak;
     CheckBox checkBoxgain,checkBoxsound;
    EditText numb1,numb2,SubEntropy1,SubEntropy2,SubEntropy3,SubEntropy4;
    TextView result,result2,entropytext1,entropytext2;
    Button mod,power,log,root,add,sub,mult,div,sine,cosine,tangent,sineh,cosineh,tangenth,Entropy,Gain;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tospeak=new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status != TextToSpeech.ERROR) {
                    tospeak.setLanguage(Locale.ENGLISH);
                }
            }
        });

        numb1= (EditText)findViewById(R.id.firstnumb);
        numb2= (EditText) findViewById(R.id.secondnumb);
        result= (TextView) findViewById(R.id.resultnumb);
        result2= (TextView) findViewById(R.id.resultnumb2);
        SubEntropy1= (EditText) findViewById(R.id.subentropy1);
        SubEntropy2= (EditText) findViewById(R.id.subentropy2);
        SubEntropy3= (EditText) findViewById(R.id.subentropy3);
        SubEntropy4= (EditText) findViewById(R.id.subentropy4);
        entropytext1= (TextView) findViewById(R.id.entropytxt1);
        entropytext2= (TextView) findViewById(R.id.entropytxt2);
        checkBoxgain= (CheckBox) findViewById(R.id.gainchbox);
        checkBoxgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isclicked==false){
                    entropytext1.setVisibility(View.VISIBLE);
                    entropytext2.setVisibility(View.VISIBLE);
                    SubEntropy1.setVisibility(View.VISIBLE);
                    SubEntropy2.setVisibility(View.VISIBLE);
                    SubEntropy3.setVisibility(View.VISIBLE);
                    SubEntropy4.setVisibility(View.VISIBLE);
                    isclicked=true;
                }else {
                    entropytext1.setVisibility(View.INVISIBLE);
                    entropytext2.setVisibility(View.INVISIBLE);
                    SubEntropy1.setVisibility(View.INVISIBLE);
                    SubEntropy2.setVisibility(View.INVISIBLE);
                    SubEntropy3.setVisibility(View.INVISIBLE);
                    SubEntropy4.setVisibility(View.INVISIBLE);
                    isclicked=false;
                }
            }
        });
        checkBoxsound=(CheckBox) findViewById(R.id.soundchbox);
        checkBoxsound.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onClick(View v) {
                if(sound==false){
                   // tospeak.setVoice(null);
                    tospeak.stop();
                    sound=true;
                    tospeak.shutdown();
                }else {
                    tospeak.setPitch((float) 10.2);
                }


            }
        });
        add=(Button)findViewById(R.id.addition);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double n1=0; double n2=0;
                String num1=numb1.getText().toString();
                String num2=numb2.getText().toString();

                if(num1.equals("")){
                    Toast.makeText(MainActivity.this,"Check For First Number ",Toast.LENGTH_SHORT).show();
                }else{
                    n1=Double.parseDouble(num1);
                }
                if(num2.equals("")) {
                    Toast.makeText(MainActivity.this, "Check For Second Number ", Toast.LENGTH_SHORT).show();
                }else {
                    n2=Double.parseDouble(num2);
                    double re=n1+n2;
                    String res="Addition Result Is : "+re;
                    tospeak.speak(res, TextToSpeech.QUEUE_FLUSH, null);
                    result.setText(res);
                    result2.setText(" ");
                }

                // Toast.makeText(MainActivity.this,"Mod iS : "+re,Toast.LENGTH_LONG).show();

            }
        });
        sub=(Button)findViewById(R.id.subtraction);
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double n1 = 0, n2=0;
                String num1=numb1.getText().toString();
                String num2=numb2.getText().toString();

                if(num1.equals("")){
                    Toast.makeText(MainActivity.this,"Check For First Number ",Toast.LENGTH_SHORT).show();
                }else{
                    n1=Double.parseDouble(num1);
                }
                if(num2.equals("")) {
                    Toast.makeText(MainActivity.this, "Check For Second Number ", Toast.LENGTH_SHORT).show();
                }else {
                    n2=Double.parseDouble(num2);
                    if(n1<n2){
                        Toast.makeText(MainActivity.this, "Sorry Negative Result ", Toast.LENGTH_SHORT).show();
                        tospeak.speak("Sorry Negative Result", TextToSpeech.QUEUE_FLUSH, null);
                    }else{
                        double re=n1-n2;
                        String res="Subtaction Result Is : "+re;
                        tospeak.speak(res, TextToSpeech.QUEUE_FLUSH, null);
                        result.setText(res);
                        result2.setText(" ");
                    }
                }

            }
        });
        mult=(Button)findViewById(R.id.multiplication);
        mult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double n1 = 0, n2=0;
                String num1=numb1.getText().toString();
                String num2=numb2.getText().toString();

                if(num1.equals("")){
                    Toast.makeText(MainActivity.this,"Check For First Number ",Toast.LENGTH_SHORT).show();
                }else{
                    n1=Double.parseDouble(num1);
                }
                if(num2.equals("")) {
                    Toast.makeText(MainActivity.this, "Check For Second Number ", Toast.LENGTH_SHORT).show();
                }else {
                    n2=Double.parseDouble(num2);
                    if(n1<=0||n2<=0){
                        Toast.makeText(MainActivity.this, "Zero or negative number ", Toast.LENGTH_SHORT).show();
                        tospeak.speak("Zero or negative number ", TextToSpeech.QUEUE_FLUSH, null);
                    }else{
                        double re=n1*n2;
                        String res="Multiplication Result Is : "+re;
                        tospeak.speak(res, TextToSpeech.QUEUE_FLUSH, null);
                        result.setText(res);
                        result2.setText(" ");
                    }

                }
            }
        });
        div=(Button)findViewById(R.id.divid);
        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double n1 = 0, n2=0;
                String num1=numb1.getText().toString();
                String num2=numb2.getText().toString();

                if(num1.equals("")){
                    Toast.makeText(MainActivity.this,"Check For First Number ",Toast.LENGTH_SHORT).show();
                }else{
                    n1=Double.parseDouble(num1);
                }
                if(num2.equals("")) {
                    Toast.makeText(MainActivity.this, "Check For Second Number ", Toast.LENGTH_SHORT).show();
                }else {
                    n2=Double.parseDouble(num2);
                    if(n2<=0){
                        Toast.makeText(MainActivity.this, "Sorry Can't Divid On 0 Or Negative ", Toast.LENGTH_SHORT).show();
                        tospeak.speak("Sorry Can't Divid On zero Or Negative", TextToSpeech.QUEUE_FLUSH, null);
                    }else{
                        double re=n1/n2;
                        String res="Divition Result Is : "+re;
                        tospeak.speak(res, TextToSpeech.QUEUE_FLUSH, null);
                        result.setText(res);
                        result2.setText(" ");
                    }
                }
            }
        });

        mod=(Button)findViewById(R.id.mod);
        mod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                long n1=0; long n2=0;
                String num1=numb1.getText().toString();
                String num2=numb2.getText().toString();

                if(num1.equals("")){
                    Toast.makeText(MainActivity.this,"Check For First Number ",Toast.LENGTH_SHORT).show();
                }else{
                    n1=Long.parseLong(num1);
                }
                if(num2.equals("")) {
                    Toast.makeText(MainActivity.this, "Check For Second Number ", Toast.LENGTH_SHORT).show();
                }else {
                     n2=Long.parseLong(num2);

                    long re=n1%n2;
                    String res= n1+" Modulus "+n2+" Is : "+re;
                    tospeak.speak(res, TextToSpeech.QUEUE_FLUSH, null);
                    result.setText(res);
                    result2.setText(" ");
                }

               // Toast.makeText(MainActivity.this,"Mod iS : "+re,Toast.LENGTH_LONG).show();

            }
        });
        power=(Button)findViewById(R.id.power);
        power.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double n1 = 0, n2=0;
                String num1=numb1.getText().toString();
                String num2=numb2.getText().toString();

                if(num1.equals("")){
                    Toast.makeText(MainActivity.this,"Check For First Number ",Toast.LENGTH_SHORT).show();
                }else{
                    n1=Double.parseDouble(num1);
                }
                if(num2.equals("")) {
                    Toast.makeText(MainActivity.this, "Check For Second Number ", Toast.LENGTH_SHORT).show();
                }else {
                    n2=Double.parseDouble(num2);
                    double re=Math.pow(n1,n2);
                    String res=n1+" Power "+n2+" Is : "+re;
                    tospeak.speak(res, TextToSpeech.QUEUE_FLUSH, null);
                    result.setText(res);
                    result2.setText(" ");
                }

            }
        });
        log=(Button)findViewById(R.id.log);
        log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double n1 = 0, n2=0;
                String num1=numb1.getText().toString();
                String num2=numb2.getText().toString();

                if(num1.equals("")){
                    Toast.makeText(MainActivity.this,"Check For First Number ",Toast.LENGTH_SHORT).show();
                }else{
                    n1=Double.parseDouble(num1);
                }
                if(num2.equals("")) {
                    Toast.makeText(MainActivity.this, "Check For Second Number ", Toast.LENGTH_SHORT).show();
                }else {
                    n2=Double.parseDouble(num2);
                    double re=Math.log10(n1)/Math.log10(n2);
                    String res=" Log "+n1+" To base "+n2+" Is : "+re;
                    tospeak.speak(res, TextToSpeech.QUEUE_FLUSH, null);
                    result.setText(res);


                }
            }
        });
        root=(Button)findViewById(R.id.root);
        root.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double n1 = 0, n2=0;
                String num1=numb1.getText().toString();
                String num2=numb2.getText().toString();

                if(num1.equals("")){
                    Toast.makeText(MainActivity.this,"Check For First Number ",Toast.LENGTH_SHORT).show();
                }else{
                    n1=Double.parseDouble(num1);
                }
                if(num2.equals("")) {
                    Toast.makeText(MainActivity.this, "Check For Second Number ", Toast.LENGTH_SHORT).show();
                }else {
                    n2=Double.parseDouble(num2);
                    double re=Math.pow(n1,1/n2);
                    String res=n1+"To Root "+n2+" Is : "+re;
                    tospeak.speak(res, TextToSpeech.QUEUE_FLUSH, null);
                    result.setText(res);
                    result2.setText(" ");
                }
            }
        });
        sine=(Button)findViewById(R.id.sin);
        sine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double n1 = 0, n2=0;
                String num1=numb1.getText().toString();
                String num2=numb2.getText().toString();

                if(num1.equals("")){
                    Toast.makeText(MainActivity.this,"Check For First Number ",Toast.LENGTH_SHORT).show();
                }else{
                    n1=Double.parseDouble(num1);
                }
                if(num2.equals("")) {
                    Toast.makeText(MainActivity.this, "Check For Second Number ", Toast.LENGTH_SHORT).show();
                }else {
                    n2=Double.parseDouble(num2);
                    if(n1<0||n2<0){
                        Toast.makeText(MainActivity.this, "No Sine for negative angle ", Toast.LENGTH_SHORT).show();
                        tospeak.speak("No Sine for negative angle ", TextToSpeech.QUEUE_FLUSH, null);
                    }else{
                    double re=Math.sin(n1);
                    double re2=Math.sin(n2);
                    String res=" Sine for angle "+n1+" Is : "+re;
                    String res2=" Sine for angle "+n2+" Is : "+re2;
                    String speak=res+" And "+res2;
                    tospeak.speak(speak, TextToSpeech.QUEUE_FLUSH, null);
                    result.setText(res);
                    result2.setText(res2);}
                }
            }
        });
        cosine=(Button)findViewById(R.id.cos);
        cosine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double n1 = 0, n2=0;
                String num1=numb1.getText().toString();
                String num2=numb2.getText().toString();

                if(num1.equals("")){
                    Toast.makeText(MainActivity.this,"Check For First Number ",Toast.LENGTH_SHORT).show();
                }else{
                    n1=Double.parseDouble(num1);
                }
                if(num2.equals("")) {
                    Toast.makeText(MainActivity.this, "Check For Second Number ", Toast.LENGTH_SHORT).show();
                }else {
                    n2=Double.parseDouble(num2);
                    if(n1<0||n2<0){
                        Toast.makeText(MainActivity.this, "No Cosine for negative angle ", Toast.LENGTH_SHORT).show();
                        tospeak.speak("No Cosine for negative angle ", TextToSpeech.QUEUE_FLUSH, null);
                    }else{
                    double re=Math.cos(n1);
                    double re2=Math.cos(n2);
                    String res=" Cosine for angle "+n1+" Is : "+re;
                    String res2=" Cosine for angle"+n2+" Is : "+re2;
                        String speak=res+" And "+res2;
                    tospeak.speak(speak, TextToSpeech.QUEUE_FLUSH, null);
                    result.setText(res);
                    result2.setText(res2);}
                }

            }
        });
        tangent=(Button)findViewById(R.id.tan);
        tangent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double n1 = 0, n2=0;
                String num1=numb1.getText().toString();
                String num2=numb2.getText().toString();

                if(num1.equals("")){
                    Toast.makeText(MainActivity.this,"Check For First Number ",Toast.LENGTH_SHORT).show();
                }else{
                    n1=Double.parseDouble(num1);
                }
                if(num2.equals("")) {
                    Toast.makeText(MainActivity.this, "Check For Second Number ", Toast.LENGTH_SHORT).show();
                }else {
                    n2=Double.parseDouble(num2);
                    if(n1<0||n2<0){
                        Toast.makeText(MainActivity.this, "No Tangent for negative angle ", Toast.LENGTH_SHORT).show();
                        tospeak.speak("No Tangent for negative angle ", TextToSpeech.QUEUE_FLUSH, null);
                    }else{
                    double re=Math.tan(n1);
                    double re2=Math.tan(n2);
                    String res=" Tangent for angle "+n1+" Is : "+re;
                    String res2=" Tangent for angle "+n2+" Is : "+re2;
                        String speak=res+" And "+res2;
                    tospeak.speak(speak, TextToSpeech.QUEUE_FLUSH, null);
                    result.setText(res);
                    result2.setText(res2);}
                }
            }
        });

        Entropy=(Button)findViewById(R.id.entropy);
        Entropy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double n1 = 0, n2=0;
                double total;
                String num1=numb1.getText().toString();
                String num2=numb2.getText().toString();

                if(num1.equals("")){
                    Toast.makeText(MainActivity.this,"Check For First Number ",Toast.LENGTH_SHORT).show();
                }else{
                    n1=Double.parseDouble(num1);
                }
                if(num2.equals("")) {
                    Toast.makeText(MainActivity.this, "Check For Second Number ", Toast.LENGTH_SHORT).show();
                }else {
                    n2=Double.parseDouble(num2);
                    if(n1==0||n2==0){
                        double entropy=0;
                        String res=" Entropy for  "+n2+" And "+n1+" Is : "+entropy;
                        tospeak.speak(res, TextToSpeech.QUEUE_FLUSH, null);
                        result.setText(res);
                        result2.setText(" ");
                    }else if(n1<0&&n2>0){
                        n1*=-1;
                        total=n1+n2;
                        double firsthalf=n1/total*(Math.log10(n1/total)/Math.log10(2));
                        double secondhalf=n2/total*(Math.log10(n2/total)/Math.log10(2));
                        double entropy=-secondhalf-firsthalf;
                        String res=" Entropy for  "+n1+" And "+-n2+" Is : "+entropy;

                        tospeak.speak(res, TextToSpeech.QUEUE_FLUSH, null);
                        result.setText(res);
                        result2.setText(" ");
                    }else if(n2<0&&n1>0){
                        n2*=-1;
                        total=n2+n1;
                        double firsthalf=n1/total*(Math.log10(n1/total)/Math.log10(2));
                        double secondhalf=n2/total*(Math.log10(n2/total)/Math.log10(2));
                        double entropy=-firsthalf-secondhalf;
                        String res=" Entropy for  "+n1+" And "+-n2+" Is : "+entropy;

                        tospeak.speak(res, TextToSpeech.QUEUE_FLUSH, null);
                        result.setText(res);
                        result2.setText(" ");}
                }
            }
        });

        sineh=(Button)findViewById(R.id.sinh);
        sineh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double n1 = 0, n2=0;
                String num1=numb1.getText().toString();
                String num2=numb2.getText().toString();

                if(num1.equals("")){
                    Toast.makeText(MainActivity.this,"Check For First Number ",Toast.LENGTH_SHORT).show();
                }else{
                    n1=Double.parseDouble(num1);
                }
                if(num2.equals("")) {
                    Toast.makeText(MainActivity.this, "Check For Second Number ", Toast.LENGTH_SHORT).show();
                }else {
                    n2=Double.parseDouble(num2);
                    if(n1<0||n2<0){
                        Toast.makeText(MainActivity.this, "No Sineh for negative angle ", Toast.LENGTH_SHORT).show();
                        tospeak.speak("No Sineh for negative angle ", TextToSpeech.QUEUE_FLUSH, null);
                    }else{
                        double re=Math.sinh(n1);
                        double re2=Math.sinh(n2);
                        String res=" Sineh for angle "+n1+" Is : "+re;
                        String res2=" Sineh for angle "+n2+" Is : "+re2;
                        String speak=res+" And "+res2;
                        tospeak.speak(speak, TextToSpeech.QUEUE_FLUSH, null);
                        result.setText(res);
                        result2.setText(res2);}
                }
            }
        });
        cosineh=(Button)findViewById(R.id.cosh);
        cosineh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double n1 = 0, n2=0;
                String num1=numb1.getText().toString();
                String num2=numb2.getText().toString();

                if(num1.equals("")){
                    Toast.makeText(MainActivity.this,"Check For First Number ",Toast.LENGTH_SHORT).show();
                }else{
                    n1=Double.parseDouble(num1);
                }
                if(num2.equals("")) {
                    Toast.makeText(MainActivity.this, "Check For Second Number ", Toast.LENGTH_SHORT).show();
                }else {
                    n2=Double.parseDouble(num2);
                    if(n1<0||n2<0){
                        Toast.makeText(MainActivity.this, "No Cosineh for negative angle ", Toast.LENGTH_SHORT).show();
                        tospeak.speak("No Cosineh for negative angle ", TextToSpeech.QUEUE_FLUSH, null);
                    }else{
                        double re=Math.cosh(n1);
                        double re2=Math.cosh(n2);
                        String res=" Cosineh for angle "+n1+" Is : "+re;
                        String res2=" Cosineh for angle"+n2+" Is : "+re2;
                        String speak=res+" And "+res2;
                        tospeak.speak(speak, TextToSpeech.QUEUE_FLUSH, null);
                        result.setText(res);
                        result2.setText(res2);}
                }

            }
        });
        tangenth=(Button)findViewById(R.id.tanh);
        tangenth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double n1 = 0, n2=0;
                String num1=numb1.getText().toString();
                String num2=numb2.getText().toString();

                if(num1.equals("")){
                    Toast.makeText(MainActivity.this,"Check For First Number ",Toast.LENGTH_SHORT).show();
                }else{
                    n1=Double.parseDouble(num1);
                }
                if(num2.equals("")) {
                    Toast.makeText(MainActivity.this, "Check For Second Number ", Toast.LENGTH_SHORT).show();
                }else {
                    n2=Double.parseDouble(num2);
                    if(n1<0||n2<0){
                        Toast.makeText(MainActivity.this, "No Tangenth for negative angle ", Toast.LENGTH_SHORT).show();
                        tospeak.speak("No Tangenth for negative angle ", TextToSpeech.QUEUE_FLUSH, null);
                    }else{
                        double re=Math.tanh(n1);
                        double re2=Math.tanh(n2);
                        String res=" Tangenth for angle "+n1+" Is : "+re;
                        String res2=" Tangenth for angle "+n2+" Is : "+re2;
                        String speak=res+" And "+res2;
                        tospeak.speak(speak, TextToSpeech.QUEUE_FLUSH, null);
                        result.setText(res);
                        result2.setText(res2);}
                }
            }
        });
        Gain=(Button)findViewById(R.id.gain);
        Gain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double n1 = 0, n2=0,subn1=0,subn2=0,subn3=0,subn4=0;
                double globaltotal=0,subtotal1=0,subtotal2=0,globalentropy=0,subentropy1=0,subentropy2=0,finalgain=0;
                String num1=numb1.getText().toString();
                String num2=numb2.getText().toString();
                String subnum1=SubEntropy1.getText().toString();
                String subnum2=SubEntropy2.getText().toString();
                String subnum3=SubEntropy3.getText().toString();
                String subnum4=SubEntropy4.getText().toString();
                if(isclicked==false){
                    Toast.makeText(MainActivity.this,"Check For Gain Checkbox ",Toast.LENGTH_SHORT).show();
                    tospeak.speak("Check For Gain Checkbox ", TextToSpeech.QUEUE_FLUSH, null);
                }else {

                if(num1.equals("")){
                    Toast.makeText(MainActivity.this,"Check For First Number ",Toast.LENGTH_SHORT).show();
                }else{
                    n1=Double.parseDouble(num1);
                }
                if(num2.equals("")) {
                    Toast.makeText(MainActivity.this, "Check For Second Number ", Toast.LENGTH_SHORT).show();
                }else {
                    n2 = Double.parseDouble(num2);
                }
                    if(subnum1.equals("")){
                        Toast.makeText(MainActivity.this,"Check For Sub Number1 ",Toast.LENGTH_SHORT).show();
                    }else{
                        subn1=Double.parseDouble(subnum1);
                    }
                    if(subnum2.equals("")) {
                        Toast.makeText(MainActivity.this, "Check For Sub Number2 ", Toast.LENGTH_SHORT).show();
                    }else {
                        subn2=Double.parseDouble(subnum2);
                    }if(subnum3.equals("")){
                        Toast.makeText(MainActivity.this,"Check For Sub Number3 ",Toast.LENGTH_SHORT).show();
                    }else{
                        subn3=Double.parseDouble(subnum3);
                    }
                    if(subnum4.equals("")) {
                        Toast.makeText(MainActivity.this, "Check For Sub Number4 ", Toast.LENGTH_SHORT).show();
                    }else {
                        subn4=Double.parseDouble(subnum4);
                        if(n1==0||n2==0){
                            globalentropy=0;

                        }else if(n1<0&&n2>0){
                        n1*=-1;
                        globaltotal=n1+n2;
                        double firsthalf=n1/globaltotal*(Math.log10(n1/globaltotal)/Math.log10(2));
                        double secondhalf=n2/globaltotal*(Math.log10(n2/globaltotal)/Math.log10(2));
                         globalentropy=-secondhalf-firsthalf;
                            n1*=-1;
                    }else if(n2<0&&n1>0){
                        n2*=-1;
                        globaltotal=n2+n1;
                        double firsthalf=n1/globaltotal*(Math.log10(n1/globaltotal)/Math.log10(2));
                        double secondhalf=n2/globaltotal*(Math.log10(n2/globaltotal)/Math.log10(2));
                         globalentropy=-firsthalf-secondhalf;
                            n2*=-1;
                        }
                        if(subn1==0||subn2==0){
                            subentropy1=0;

                        }else if(subn1<0&&subn2>0){
                            subn1*=-1;
                            subtotal1=subn1+subn2;
                            double firsthalf=subn1/subtotal1*(Math.log10(subn1/subtotal1)/Math.log10(2));
                            double secondhalf=subn2/subtotal1*(Math.log10(subn2/subtotal1)/Math.log10(2));
                            subentropy1=-secondhalf-firsthalf;
                        }else if(subn2<0&&subn1>0){
                            subn2*=-1;
                            subtotal1=subn2+subn1;
                            double firsthalf=subn1/subtotal1*(Math.log10(subn1/subtotal1)/Math.log10(2));
                            double secondhalf=subn2/subtotal1*(Math.log10(subn2/subtotal1)/Math.log10(2));
                            subentropy1=-firsthalf-secondhalf;
                            }
                        if(subn3==0||subn4==0){
                            subentropy2=0;

                        }else if(subn3<0&&subn4>0){
                            subn3*=-1;
                            subtotal2=subn3+subn4;
                            double firsthalf=subn3/subtotal2*(Math.log10(subn3/subtotal2)/Math.log10(2));
                            double secondhalf=subn4/subtotal2*(Math.log10(subn4/subtotal2)/Math.log10(2));
                            subentropy2=-secondhalf-firsthalf;

                        }else if(subn4<0&&subn3>0){
                            subn4*=-1;
                            subtotal2=subn4+subn3;
                            double firsthalf=subn3/subtotal2*(Math.log10(subn3/subtotal2)/Math.log10(2));
                            double secondhalf=subn4/subtotal2*(Math.log10(subn4/subtotal2)/Math.log10(2));
                            subentropy2 =-firsthalf-secondhalf;
                            }
                        finalgain=globalentropy-((subtotal1/globaltotal)*subentropy1)-((subtotal2/globaltotal)*subentropy2);
                        String res=" Gain for  "+n1+" And "+n2+" Is : "+finalgain;

                        tospeak.speak(res, TextToSpeech.QUEUE_FLUSH, null);
                        result.setText(res);
                        result2.setText(" ");
                }

                }
            }
        });
    }
    public void onPause(){
        if(tospeak !=null){
            tospeak.stop();
            tospeak.shutdown();
        }
        super.onPause();
    }
}
